# Zahara ERP API Documentation

## Overview

This document provides comprehensive API documentation for the Zahara ERP system, designed for integration with modern frontend frameworks like Next.js and TypeScript.

## Base Configuration

### Base URL
```
Development: http://localhost:8000/api/v1/
Production: https://your-domain.com/api/v1/
```

### Authentication
```typescript
// JWT Token Authentication (Recommended)
Authorization: Bearer <jwt_token>

// Session Authentication (Fallback)
Cookie: sessionid=<session_id>

// CSRF Token (for Django forms)
X-CSRFToken: <csrf_token>
```

### Content Types
```typescript
Content-Type: application/json
Accept: application/json
```

## Current API Endpoints (Existing)

### Orders API

#### Get Customer Branches
```http
GET /orders/get-branches/?customer_id={id}
```

**Response:**
```typescript
interface Branch {
  id: number;
  name: string;
}

// Response
Branch[]
```

#### Get Customer Orders
```http
GET /orders/get-orders/?customer_id={id}
```

**Response:**
```typescript
interface OrderSummary {
  id: number;
  invoice_code: string;
  date: string; // YYYY-MM-DD
  total_amount: string; // Decimal as string
}

// Response
OrderSummary[]
```

#### Get Customer Pricing
```http
GET /orders/get-customer-pricing/?product_id={id}&stem_length={cm}
```

**Response:**
```typescript
interface CustomerPricing {
  customer_name: string;
  product_name: string;
  stem_length_cm: number;
  price_per_stem: string; // Decimal as string
  currency: string;
}

interface PricingResponse {
  success: boolean;
  pricing: CustomerPricing[];
  count: number;
}
```

#### Get Customer-Product Defaults
```http
POST /orders/get-defaults/
Content-Type: application/x-www-form-urlencoded

customer_id={id}&product_id={id}
```

**Response:**
```typescript
interface DefaultsResponse {
  success: boolean;
  stem_length_cm?: number;
  price_per_stem?: string;
  error?: string;
}
```

### Payments API

#### Get Outstanding Orders
```http
GET /payments/get-outstanding-orders/{customer_id}/
```

**Response:**
```typescript
interface OutstandingOrder {
  id: number;
  invoice_code: string;
  date: string;
  total_amount: string;
  outstanding_amount: string;
}

// Response
{
  orders: OutstandingOrder[]
}
```

#### Get Customer Balance
```http
GET /payments/get-customer-balance/{customer_id}/
```

**Response:**
```typescript
interface BalanceResponse {
  balance: string; // Decimal as string
  currency: string;
}
```

#### Allocate Payment
```http
POST /payments/allocate-payment/{payment_id}/
Content-Type: application/json

{
  "allocations": [
    {
      "order_id": number,
      "amount": string
    }
  ]
}
```

**Response:**
```typescript
interface AllocationResult {
  id: number;
  order_invoice: string;
  amount: string;
}

interface AllocationResponse {
  success: boolean;
  allocations: AllocationResult[];
  remaining_amount: string;
  error?: string;
}
```

#### Recalculate Balance
```http
POST /payments/recalculate-balance/{customer_id}/
```

**Response:**
```typescript
interface RecalculateResponse {
  success: boolean;
  balance: string;
  currency: string;
  error?: string;
}
```

## Recommended Complete API Implementation

### 1. Customers API

#### Get All Customers
```http
GET /api/v1/customers/
```

**Query Parameters:**
- `search`: string - Search by name or short_code
- `currency`: string - Filter by preferred_currency
- `page`: number - Page number for pagination
- `page_size`: number - Items per page (default: 20)

**Response:**
```typescript
interface Customer {
  id: number;
  name: string;
  short_code: string;
  preferred_currency: 'KSH' | 'USD' | 'GBP' | 'EUR';
  branches: Branch[];
  order_statistics: {
    total_orders: number;
    total_sales: string;
    pending_orders: number;
    paid_orders: number;
    claimed_orders: number;
    cancelled_orders: number;
  };
  current_balance: string;
  created_at: string;
  updated_at: string;
}

interface PaginatedCustomers {
  count: number;
  next: string | null;
  previous: string | null;
  results: Customer[];
}
```

#### Get Customer Detail
```http
GET /api/v1/customers/{id}/
```

**Response:**
```typescript
interface CustomerDetail extends Customer {
  recent_orders: OrderSummary[];
  payment_history: PaymentSummary[];
  account_statements: StatementSummary[];
}
```

#### Create Customer
```http
POST /api/v1/customers/
Content-Type: application/json

{
  "name": string;
  "short_code": string;
  "preferred_currency": 'KSH' | 'USD' | 'GBP' | 'EUR';
}
```

#### Update Customer
```http
PUT /api/v1/customers/{id}/
PATCH /api/v1/customers/{id}/
```

#### Delete Customer
```http
DELETE /api/v1/customers/{id}/
```

### 2. Products API

#### Get All Products
```http
GET /api/v1/products/
```

**Response:**
```typescript
interface Product {
  id: number;
  name: string;
  stem_length_cm: number;
  customer_prices: CustomerProductPrice[];
  created_at: string;
}

interface CustomerProductPrice {
  id: number;
  customer: {
    id: number;
    name: string;
    short_code: string;
  };
  stem_length_cm: number;
  price_per_stem: string;
  currency: string;
  last_updated: string;
}
```

#### Get Product Detail
```http
GET /api/v1/products/{id}/
```

#### Create Product
```http
POST /api/v1/products/
Content-Type: application/json

{
  "name": string;
  "stem_length_cm": number;
}
```

### 3. Orders API (Complete)

#### Get All Orders
```http
GET /api/v1/orders/
```

**Query Parameters:**
- `customer`: number - Filter by customer ID
- `status`: string - Filter by status (pending, paid, claim, cancelled)
- `date_from`: string - Filter orders from date (YYYY-MM-DD)
- `date_to`: string - Filter orders to date (YYYY-MM-DD)
- `search`: string - Search by invoice code
- `page`: number - Page number
- `page_size`: number - Items per page

**Response:**
```typescript
interface Order {
  id: number;
  invoice_code: string;
  customer: {
    id: number;
    name: string;
    short_code: string;
  };
  branch: {
    id: number;
    name: string;
  } | null;
  total_amount: string;
  currency: string;
  date: string;
  status: 'pending' | 'paid' | 'claim' | 'cancelled';
  status_reason: string | null;
  remarks: string | null;
  logistics_provider: string | null;
  logistics_cost: string | null;
  tracking_number: string | null;
  delivery_status: string | null;
  items: OrderItem[];
  payment_status: 'fully_paid' | 'partially_paid' | 'unpaid';
  outstanding_amount: string;
  total_paid_amount: string;
  credit_notes: CreditNoteSummary[];
  created_at: string;
  updated_at: string;
}

interface OrderItem {
  id: number;
  product: {
    id: number;
    name: string;
    stem_length_cm: number;
  };
  stem_length_cm: number;
  boxes: number;
  stems_per_box: number;
  stems: number;
  price_per_stem: string;
  total_amount: string;
}

interface CreditNoteSummary {
  id: number;
  code: string;
  total_credit_amount: string;
  status: 'pending' | 'applied' | 'cancelled';
  created_at: string;
}
```

#### Create Order
```http
POST /api/v1/orders/
Content-Type: application/json

{
  "customer": number;
  "branch": number | null;
  "date": string; // YYYY-MM-DD
  "remarks": string | null;
  "logistics_provider": string | null;
  "logistics_cost": string | null;
  "tracking_number": string | null;
  "delivery_status": string | null;
  "items": [
    {
      "product": number;
      "stem_length_cm": number;
      "boxes": number;
      "stems_per_box": number;
      "price_per_stem": string;
    }
  ];
}
```

#### Update Order
```http
PUT /api/v1/orders/{id}/
PATCH /api/v1/orders/{id}/
```

#### Delete Order
```http
DELETE /api/v1/orders/{id}/
```

#### Mark Order as Claim
```http
POST /api/v1/orders/{id}/mark-claim/
Content-Type: application/json

{
  "reason": string;
}
```

#### Cancel Order
```http
POST /api/v1/orders/{id}/cancel/
Content-Type: application/json

{
  "reason": string;
}
```

### 4. Payments API (Complete)

#### Get All Payments
```http
GET /api/v1/payments/
```

**Query Parameters:**
- `customer`: number - Filter by customer ID
- `status`: string - Filter by status
- `payment_method`: string - Filter by payment method
- `date_from`: string - Filter from date
- `date_to`: string - Filter to date
- `search`: string - Search by reference number or notes

**Response:**
```typescript
interface Payment {
  payment_id: string; // UUID
  customer: {
    id: number;
    name: string;
    short_code: string;
  };
  payment_type: {
    id: number;
    name: string;
    mode: string;
  };
  amount: string;
  currency: string;
  payment_method: 'cash' | 'bank_transfer' | 'check' | 'credit_card' | 'mobile_money' | 'other';
  payment_date: string;
  status: 'pending' | 'completed' | 'cancelled' | 'refunded';
  reference_number: string | null;
  notes: string | null;
  allocated_amount: string;
  unallocated_amount: string;
  is_fully_allocated: boolean;
  allocations: PaymentAllocation[];
  created_at: string;
  updated_at: string;
}

interface PaymentAllocation {
  id: number;
  order: {
    id: number;
    invoice_code: string;
    date: string;
  };
  amount: string;
  allocated_at: string;
}
```

#### Create Payment
```http
POST /api/v1/payments/
Content-Type: application/json

{
  "customer": number;
  "payment_type": number;
  "amount": string;
  "payment_method": string;
  "payment_date": string;
  "reference_number": string | null;
  "notes": string | null;
  "status": string; // Default: 'completed'
}
```

#### Allocate Payment
```http
POST /api/v1/payments/{payment_id}/allocate/
Content-Type: application/json

{
  "allocations": [
    {
      "order_id": number;
      "amount": string;
    }
  ];
}
```

### 5. Credit Notes API

#### Get All Credit Notes
```http
GET /api/v1/credit-notes/
```

**Response:**
```typescript
interface CreditNote {
  id: number;
  code: string;
  order: {
    id: number;
    invoice_code: string;
    customer: {
      id: number;
      name: string;
    };
  };
  title: string;
  reason: string;
  total_credit_amount: string;
  currency: string;
  status: 'pending' | 'applied' | 'cancelled';
  credit_type: 'order_reduction' | 'customer_credit';
  created_by: {
    id: number;
    username: string;
  } | null;
  created_at: string;
  updated_at: string;
  applied_at: string | null;
  items: CreditNoteItem[];
}

interface CreditNoteItem {
  id: number;
  order_item: {
    id: number;
    product: {
      id: number;
      name: string;
    };
    stems: number;
    price_per_stem: string;
  };
  stems_affected: number;
  credit_amount: string;
  reason: string | null;
}
```

#### Create Credit Note
```http
POST /api/v1/credit-notes/
Content-Type: application/json

{
  "order": number;
  "title": string;
  "reason": string;
  "items": [
    {
      "order_item": number;
      "stems_affected": number;
      "reason": string | null;
    }
  ];
}
```

### 6. Expenses API

#### Get All Expenses
```http
GET /api/v1/expenses/
```

**Response:**
```typescript
interface Expense {
  id: number;
  name: string;
  amount: string;
  currency: string;
  reference_number: string | null;
  category: {
    id: number;
    name: string;
    color: string;
  } | null;
  description: string | null;
  date_incurred: string;
  due_date: string | null;
  status: 'pending' | 'approved' | 'rejected' | 'paid';
  approved_by: string | null;
  approved_at: string | null;
  rejection_reason: string | null;
  payment_method: string | null;
  payment_date: string | null;
  vendor_name: string | null;
  vendor_contact: string | null;
  is_recurring: boolean;
  recurring_frequency: string | null;
  tags: string | null;
  created_by: string | null;
  created_at: string;
  updated_at: string;
  attachments: ExpenseAttachment[];
}

interface ExpenseAttachment {
  id: number;
  file: string; // URL
  file_type: 'receipt' | 'invoice' | 'photo' | 'document' | 'other';
  original_filename: string;
  description: string | null;
  uploaded_at: string;
}
```

### 7. Analytics & Reports API

#### Dashboard Statistics
```http
GET /api/v1/analytics/dashboard/
```

**Response:**
```typescript
interface DashboardStats {
  total_orders: number;
  total_sales: string;
  pending_orders: number;
  paid_orders: number;
  claim_orders: number;
  total_payments: string;
  total_outstanding: string;
  top_customers: Array<{
    id: number;
    name: string;
    total_sales: string;
    order_count: number;
  }>;
  recent_orders: OrderSummary[];
  recent_payments: PaymentSummary[];
  monthly_sales: Array<{
    month: string;
    sales: string;
    orders: number;
  }>;
}
```

#### Sales Analytics
```http
GET /api/v1/analytics/sales/
```

**Query Parameters:**
- `period`: string - '7d', '30d', '90d', '1y'
- `group_by`: string - 'day', 'week', 'month'

#### Payment Analytics
```http
GET /api/v1/analytics/payments/
```

#### Customer Analytics
```http
GET /api/v1/analytics/customers/
```

### 8. File Upload API

#### Upload File
```http
POST /api/v1/files/upload/
Content-Type: multipart/form-data

{
  "file": File;
  "type": 'expense_attachment' | 'invoice_pdf' | 'statement_pdf';
  "description": string | null;
}
```

**Response:**
```typescript
interface FileUploadResponse {
  id: number;
  file: string; // URL
  original_filename: string;
  file_size: number;
  file_type: string;
  uploaded_at: string;
}
```

## Error Handling

### Standard Error Response
```typescript
interface APIError {
  error: string;
  message: string;
  details?: Record<string, any>;
  code?: string;
}

// HTTP Status Codes
// 200 - Success
// 201 - Created
// 400 - Bad Request
// 401 - Unauthorized
// 403 - Forbidden
// 404 - Not Found
// 422 - Validation Error
// 500 - Internal Server Error
```

### Validation Errors
```typescript
interface ValidationError {
  field_name: string[];
  non_field_errors: string[];
}

// Example
{
  "amount": ["This field is required."],
  "customer": ["Invalid customer ID."],
  "non_field_errors": ["Order total cannot be zero."]
}
```

## Pagination

### Standard Pagination Response
```typescript
interface PaginatedResponse<T> {
  count: number;
  next: string | null;
  previous: string | null;
  results: T[];
}
```

### Pagination Parameters
- `page`: number (default: 1)
- `page_size`: number (default: 20, max: 100)

## Filtering & Search

### Common Query Parameters
- `search`: string - General text search
- `ordering`: string - Sort field (prefix with '-' for descending)
- `date_from`: string - Filter from date (YYYY-MM-DD)
- `date_to`: string - Filter to date (YYYY-MM-DD)

### Examples
```http
GET /api/v1/orders/?search=FL001&status=pending&ordering=-date&page=1&page_size=20
GET /api/v1/customers/?currency=USD&search=Nairobi&ordering=name
GET /api/v1/payments/?date_from=2025-01-01&date_to=2025-01-31&payment_method=bank_transfer
```

## Next.js Integration Examples

### API Client Setup
```typescript
// lib/api.ts
export class ZaharaAPI {
  private baseURL: string;
  private token: string | null = null;

  constructor(baseURL: string = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:8000/api/v1') {
    this.baseURL = baseURL;
  }

  setToken(token: string) {
    this.token = token;
  }

  private async request<T>(endpoint: string, options: RequestInit = {}): Promise<T> {
    const url = `${this.baseURL}${endpoint}`;
    const headers: HeadersInit = {
      'Content-Type': 'application/json',
      ...options.headers,
    };

    if (this.token) {
      headers.Authorization = `Bearer ${this.token}`;
    }

    const response = await fetch(url, {
      ...options,
      headers,
    });

    if (!response.ok) {
      const error = await response.json();
      throw new Error(error.message || 'API request failed');
    }

    return response.json();
  }

  // Customers
  async getCustomers(params?: CustomerListParams): Promise<PaginatedCustomers> {
    const searchParams = new URLSearchParams();
    if (params?.search) searchParams.set('search', params.search);
    if (params?.currency) searchParams.set('currency', params.currency);
    if (params?.page) searchParams.set('page', params.page.toString());

    return this.request(`/customers/?${searchParams.toString()}`);
  }

  async getCustomer(id: number): Promise<CustomerDetail> {
    return this.request(`/customers/${id}/`);
  }

  async createCustomer(data: CreateCustomerRequest): Promise<Customer> {
    return this.request('/customers/', {
      method: 'POST',
      body: JSON.stringify(data),
    });
  }

  // Orders
  async getOrders(params?: OrderListParams): Promise<PaginatedResponse<Order>> {
    const searchParams = new URLSearchParams();
    if (params?.customer) searchParams.set('customer', params.customer.toString());
    if (params?.status) searchParams.set('status', params.status);
    if (params?.search) searchParams.set('search', params.search);
    if (params?.page) searchParams.set('page', params.page.toString());

    return this.request(`/orders/?${searchParams.toString()}`);
  }

  async createOrder(data: CreateOrderRequest): Promise<Order> {
    return this.request('/orders/', {
      method: 'POST',
      body: JSON.stringify(data),
    });
  }

  // Payments
  async getPayments(params?: PaymentListParams): Promise<PaginatedResponse<Payment>> {
    const searchParams = new URLSearchParams();
    if (params?.customer) searchParams.set('customer', params.customer.toString());
    if (params?.status) searchParams.set('status', params.status);
    if (params?.date_from) searchParams.set('date_from', params.date_from);
    if (params?.date_to) searchParams.set('date_to', params.date_to);

    return this.request(`/payments/?${searchParams.toString()}`);
  }

  async allocatePayment(paymentId: string, allocations: PaymentAllocationRequest[]): Promise<AllocationResponse> {
    return this.request(`/payments/${paymentId}/allocate/`, {
      method: 'POST',
      body: JSON.stringify({ allocations }),
    });
  }
}

export const api = new ZaharaAPI();
```

### React Hooks
```typescript
// hooks/useCustomers.ts
import { useState, useEffect } from 'react';
import { api, type Customer, type CustomerListParams } from '@/lib/api';

export function useCustomers(params?: CustomerListParams) {
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [totalCount, setTotalCount] = useState(0);

  useEffect(() => {
    const fetchCustomers = async () => {
      try {
        setLoading(true);
        const response = await api.getCustomers(params);
        setCustomers(response.results);
        setTotalCount(response.count);
        setError(null);
      } catch (err) {
        setError(err instanceof Error ? err.message : 'Failed to fetch customers');
      } finally {
        setLoading(false);
      }
    };

    fetchCustomers();
  }, [params]);

  return { customers, loading, error, totalCount };
}
```

### Type Definitions
```typescript
// types/index.ts
export interface Customer {
  id: number;
  name: string;
  short_code: string;
  preferred_currency: 'KSH' | 'USD' | 'GBP' | 'EUR';
  // ... other fields
}

export interface CreateCustomerRequest {
  name: string;
  short_code: string;
  preferred_currency: 'KSH' | 'USD' | 'GBP' | 'EUR';
}

export interface CustomerListParams {
  search?: string;
  currency?: string;
  page?: number;
  page_size?: number;
}

// ... other type definitions
```

## Implementation Priority

### Phase 1: Core APIs (Week 1-2)
1. ✅ Customers API (CRUD + search)
2. ✅ Products API (CRUD)
3. ✅ Orders API (CRUD + status management)
4. ✅ Basic Payments API (CRUD)

### Phase 2: Advanced Features (Week 3-4)
1. ✅ Payment Allocation API
2. ✅ Credit Notes API
3. ✅ Expenses API
4. ✅ File Upload API

### Phase 3: Analytics & Reporting (Week 5-6)
1. ✅ Dashboard Analytics API
2. ✅ Sales Reports API
3. ✅ Payment Analytics API
4. ✅ Export/PDF Generation API

### Phase 4: Advanced Features (Week 7-8)
1. ✅ Real-time Notifications (WebSocket)
2. ✅ Bulk Operations API
3. ✅ Advanced Search & Filtering
4. ✅ API Rate Limiting & Caching

This comprehensive API will provide everything needed for a modern Next.js/TypeScript frontend while maintaining the robust Django backend architecture.


