# Django REST Framework API Implementation Plan

## Overview
This document outlines the step-by-step implementation of a comprehensive REST API for the Zahara ERP system using Django REST Framework.

## Project Structure
```
backend/
├── api/
│   ├── __init__.py
│   ├── urls.py
│   ├── serializers/
│   │   ├── __init__.py
│   │   ├── customers.py
│   │   ├── products.py
│   │   ├── orders.py
│   │   ├── payments.py
│   │   ├── expenses.py
│   │   └── analytics.py
│   ├── views/
│   │   ├── __init__.py
│   │   ├── customers.py
│   │   ├── products.py
│   │   ├── orders.py
│   │   ├── payments.py
│   │   ├── expenses.py
│   │   └── analytics.py
│   ├── permissions.py
│   ├── pagination.py
│   ├── filters.py
│   └── throttling.py
```

## Implementation Steps

### Step 1: Setup Django REST Framework

#### 1.1 Update Settings
```python
# backend/zahara_backend/settings.py

INSTALLED_APPS = [
    # ... existing apps
    'rest_framework',
    'rest_framework.authtoken',
    'corsheaders',  # For frontend integration
    'api',  # Our new API app
]

MIDDLEWARE = [
    # ... existing middleware
    'corsheaders.middleware.CorsMiddleware',
]

# REST Framework Configuration
REST_FRAMEWORK = {
    'DEFAULT_AUTHENTICATION_CLASSES': [
        'rest_framework.authentication.TokenAuthentication',
        'rest_framework.authentication.SessionAuthentication',
    ],
    'DEFAULT_PERMISSION_CLASSES': [
        'rest_framework.permissions.IsAuthenticated',
    ],
    'DEFAULT_PAGINATION_CLASS': 'api.pagination.StandardResultsSetPagination',
    'DEFAULT_FILTER_BACKENDS': [
        'django_filters.rest_framework.DjangoFilterBackend',
        'rest_framework.filters.SearchFilter',
        'rest_framework.filters.OrderingFilter',
    ],
    'DEFAULT_THROTTLE_CLASSES': [
        'rest_framework.throttling.AnonRateThrottle',
        'rest_framework.throttling.UserRateThrottle'
    ],
    'DEFAULT_THROTTLE_RATES': {
        'anon': '100/hour',
        'user': '1000/hour'
    }
}

# CORS Settings for Next.js frontend
CORS_ALLOWED_ORIGINS = [
    "http://localhost:3000",  # Next.js dev server
    "http://127.0.0.1:3000",
]

CORS_ALLOW_CREDENTIALS = True
```

#### 1.2 Create API App
```bash
cd backend
python manage.py startapp api
```

### Step 2: Core API Components

#### 2.1 Pagination
```python
# backend/api/pagination.py
from rest_framework.pagination import PageNumberPagination

class StandardResultsSetPagination(PageNumberPagination):
    page_size = 20
    page_size_query_param = 'page_size'
    max_page_size = 100
```

#### 2.2 Permissions
```python
# backend/api/permissions.py
from rest_framework.permissions import BasePermission

class IsOwnerOrReadOnly(BasePermission):
    """
    Custom permission to only allow owners of an object to edit it.
    """
    def has_object_permission(self, request, view, obj):
        # Read permissions are allowed to any request,
        # so we'll always allow GET, HEAD or OPTIONS requests.
        if request.method in ['GET', 'HEAD', 'OPTIONS']:
            return True

        # Write permissions are only allowed to the owner of the snippet.
        return obj.created_by == request.user
```

#### 2.3 Filters
```python
# backend/api/filters.py
import django_filters
from django.db.models import Q
from customers.models import Customer
from orders.models import Order
from payments.models import Payment

class CustomerFilter(django_filters.FilterSet):
    search = django_filters.CharFilter(method='filter_search')
    currency = django_filters.ChoiceFilter(choices=Customer.CURRENCY_CHOICES)

    def filter_search(self, queryset, name, value):
        return queryset.filter(
            Q(name__icontains=value) | Q(short_code__icontains=value)
        )

    class Meta:
        model = Customer
        fields = ['search', 'currency']

class OrderFilter(django_filters.FilterSet):
    search = django_filters.CharFilter(method='filter_search')
    customer = django_filters.NumberFilter(field_name='customer__id')
    status = django_filters.ChoiceFilter(choices=Order.STATUS_CHOICES)
    date_from = django_filters.DateFilter(field_name='date', lookup_expr='gte')
    date_to = django_filters.DateFilter(field_name='date', lookup_expr='lte')

    def filter_search(self, queryset, name, value):
        return queryset.filter(invoice_code__icontains=value)

    class Meta:
        model = Order
        fields = ['search', 'customer', 'status', 'date_from', 'date_to']

class PaymentFilter(django_filters.FilterSet):
    search = django_filters.CharFilter(method='filter_search')
    customer = django_filters.NumberFilter(field_name='customer__id')
    status = django_filters.ChoiceFilter(choices=Payment.STATUS_CHOICES)
    payment_method = django_filters.ChoiceFilter(choices=Payment.PAYMENT_METHOD_CHOICES)
    date_from = django_filters.DateFilter(field_name='payment_date', lookup_expr='gte')
    date_to = django_filters.DateFilter(field_name='payment_date', lookup_expr='lte')

    def filter_search(self, queryset, name, value):
        return queryset.filter(
            Q(reference_number__icontains=value) |
            Q(notes__icontains=value) |
            Q(customer__name__icontains=value)
        )

    class Meta:
        model = Payment
        fields = ['search', 'customer', 'status', 'payment_method', 'date_from', 'date_to']
```

### Step 3: Serializers

#### 3.1 Customer Serializers
```python
# backend/api/serializers/customers.py
from rest_framework import serializers
from customers.models import Customer, Branch
from orders.models import Order
from payments.models import Payment, CustomerBalance

class BranchSerializer(serializers.ModelSerializer):
    class Meta:
        model = Branch
        fields = ['id', 'name', 'short_code']

class CustomerSummarySerializer(serializers.ModelSerializer):
    class Meta:
        model = Customer
        fields = ['id', 'name', 'short_code', 'preferred_currency']

class CustomerSerializer(serializers.ModelSerializer):
    branches = BranchSerializer(many=True, read_only=True)
    order_statistics = serializers.SerializerMethodField()
    current_balance = serializers.SerializerMethodField()

    def get_order_statistics(self, obj):
        return obj.get_order_statistics()

    def get_current_balance(self, obj):
        return obj.current_balance()

    class Meta:
        model = Customer
        fields = [
            'id', 'name', 'short_code', 'preferred_currency',
            'branches', 'order_statistics', 'current_balance'
        ]

class CustomerDetailSerializer(CustomerSerializer):
    recent_orders = serializers.SerializerMethodField()
    payment_history = serializers.SerializerMethodField()

    def get_recent_orders(self, obj):
        from api.serializers.orders import OrderSummarySerializer
        orders = obj.orders.all().order_by('-date')[:10]
        return OrderSummarySerializer(orders, many=True).data

    def get_payment_history(self, obj):
        from api.serializers.payments import PaymentSummarySerializer
        payments = Payment.objects.filter(customer=obj).order_by('-payment_date')[:10]
        return PaymentSummarySerializer(payments, many=True).data

    class Meta(CustomerSerializer.Meta):
        fields = CustomerSerializer.Meta.fields + [
            'recent_orders', 'payment_history'
        ]
```

#### 3.2 Order Serializers
```python
# backend/api/serializers/orders.py
from rest_framework import serializers
from orders.models import Order, OrderItem, CustomerOrderDefaults
from customers.models import Customer, Branch
from products.models import Product, CustomerProductPrice

class ProductSerializer(serializers.ModelSerializer):
    class Meta:
        model = Product
        fields = ['id', 'name', 'stem_length_cm']

class OrderItemSerializer(serializers.ModelSerializer):
    product = ProductSerializer(read_only=True)

    class Meta:
        model = OrderItem
        fields = [
            'id', 'product', 'stem_length_cm', 'boxes',
            'stems_per_box', 'stems', 'price_per_stem', 'total_amount'
        ]

class OrderSummarySerializer(serializers.ModelSerializer):
    customer = serializers.StringRelatedField()

    class Meta:
        model = Order
        fields = [
            'id', 'invoice_code', 'customer', 'total_amount',
            'currency', 'date', 'status'
        ]

class OrderSerializer(serializers.ModelSerializer):
    items = OrderItemSerializer(many=True, read_only=True)
    customer = CustomerSummarySerializer(read_only=True)
    branch = serializers.StringRelatedField(read_only=True)
    payment_status = serializers.SerializerMethodField()
    outstanding_amount = serializers.SerializerMethodField()
    total_paid_amount = serializers.SerializerMethodField()

    def get_payment_status(self, obj):
        return obj.payment_status()

    def get_outstanding_amount(self, obj):
        return str(obj.outstanding_amount())

    def get_total_paid_amount(self, obj):
        return str(obj.total_paid_amount())

    class Meta:
        model = Order
        fields = [
            'id', 'invoice_code', 'customer', 'branch', 'total_amount',
            'currency', 'date', 'status', 'status_reason', 'remarks',
            'logistics_provider', 'logistics_cost', 'tracking_number',
            'delivery_status', 'items', 'payment_status', 'outstanding_amount',
            'total_paid_amount'
        ]

class CreateOrderSerializer(serializers.ModelSerializer):
    items = serializers.ListField(
        child=serializers.DictField(),
        write_only=True
    )

    class Meta:
        model = Order
        fields = [
            'customer', 'branch', 'date', 'remarks', 'logistics_provider',
            'logistics_cost', 'tracking_number', 'delivery_status', 'items'
        ]

    def create(self, validated_data):
        items_data = validated_data.pop('items')
        order = Order.objects.create(**validated_data)

        for item_data in items_data:
            OrderItem.objects.create(order=order, **item_data)

        return order

class CustomerOrderDefaultsSerializer(serializers.ModelSerializer):
    class Meta:
        model = CustomerOrderDefaults
        fields = ['customer', 'product', 'stem_length_cm', 'price_per_stem', 'last_used']
```

#### 3.3 Payment Serializers
```python
# backend/api/serializers/payments.py
from rest_framework import serializers
from payments.models import Payment, PaymentType, PaymentAllocation, CustomerBalance
from customers.models import Customer
from orders.models import Order

class PaymentTypeSerializer(serializers.ModelSerializer):
    class Meta:
        model = PaymentType
        fields = ['id', 'name', 'mode', 'description', 'is_active']

class PaymentAllocationSerializer(serializers.ModelSerializer):
    order = serializers.StringRelatedField(read_only=True)

    class Meta:
        model = PaymentAllocation
        fields = ['id', 'order', 'amount', 'allocated_at']

class PaymentSerializer(serializers.ModelSerializer):
    customer = serializers.StringRelatedField(read_only=True)
    payment_type = PaymentTypeSerializer(read_only=True)
    allocations = PaymentAllocationSerializer(many=True, read_only=True)
    allocated_amount = serializers.ReadOnlyField()
    unallocated_amount = serializers.ReadOnlyField()
    is_fully_allocated = serializers.ReadOnlyField()

    class Meta:
        model = Payment
        fields = [
            'payment_id', 'customer', 'payment_type', 'amount', 'currency',
            'payment_method', 'payment_date', 'status', 'reference_number',
            'notes', 'allocations', 'allocated_amount', 'unallocated_amount',
            'is_fully_allocated', 'created_at', 'updated_at'
        ]

class CreatePaymentSerializer(serializers.ModelSerializer):
    class Meta:
        model = Payment
        fields = [
            'customer', 'payment_type', 'amount', 'payment_method',
            'payment_date', 'reference_number', 'notes', 'status'
        ]

class PaymentAllocationRequestSerializer(serializers.Serializer):
    order_id = serializers.IntegerField()
    amount = serializers.DecimalField(max_digits=15, decimal_places=2)

class PaymentSummarySerializer(serializers.ModelSerializer):
    customer = serializers.StringRelatedField(read_only=True)

    class Meta:
        model = Payment
        fields = [
            'payment_id', 'customer', 'amount', 'currency',
            'payment_date', 'status', 'reference_number'
        ]
```

### Step 4: Views

#### 4.1 Customer Views
```python
# backend/api/views/customers.py
from rest_framework import viewsets, status
from rest_framework.decorators import action
from rest_framework.response import Response
from django_filters.rest_framework import DjangoFilterBackend
from rest_framework.filters import SearchFilter, OrderingFilter

from customers.models import Customer, Branch
from api.serializers.customers import (
    CustomerSerializer, CustomerDetailSerializer, BranchSerializer
)
from api.filters import CustomerFilter

class CustomerViewSet(viewsets.ModelViewSet):
    queryset = Customer.objects.all()
    serializer_class = CustomerSerializer
    filter_backends = [DjangoFilterBackend, SearchFilter, OrderingFilter]
    filterset_class = CustomerFilter
    search_fields = ['name', 'short_code']
    ordering_fields = ['name', 'created_at']
    ordering = ['name']

    def get_serializer_class(self):
        if self.action == 'retrieve':
            return CustomerDetailSerializer
        return CustomerSerializer

    @action(detail=True, methods=['get'])
    def balance(self, request, pk=None):
        customer = self.get_object()
        balance = customer.current_balance()
        return Response({
            'balance': str(balance),
            'currency': customer.preferred_currency
        })

    @action(detail=True, methods=['post'])
    def recalculate_balance(self, request, pk=None):
        customer = self.get_object()
        from payments.models import CustomerBalance
        balance, created = CustomerBalance.objects.get_or_create(
            customer=customer,
            defaults={'currency': customer.preferred_currency}
        )
        new_balance = balance.recalculate_balance()
        return Response({
            'success': True,
            'balance': str(new_balance),
            'currency': customer.preferred_currency
        })

class BranchViewSet(viewsets.ModelViewSet):
    queryset = Branch.objects.all()
    serializer_class = BranchSerializer
    filter_backends = [DjangoFilterBackend]
    filterset_fields = ['customer']
```

#### 4.2 Order Views
```python
# backend/api/views/orders.py
from rest_framework import viewsets, status
from rest_framework.decorators import action
from rest_framework.response import Response
from django_filters.rest_framework import DjangoFilterBackend
from rest_framework.filters import SearchFilter, OrderingFilter

from orders.models import Order, OrderItem, CustomerOrderDefaults
from api.serializers.orders import (
    OrderSerializer, CreateOrderSerializer, OrderItemSerializer,
    CustomerOrderDefaultsSerializer
)
from api.filters import OrderFilter

class OrderViewSet(viewsets.ModelViewSet):
    queryset = Order.objects.all()
    filter_backends = [DjangoFilterBackend, SearchFilter, OrderingFilter]
    filterset_class = OrderFilter
    search_fields = ['invoice_code']
    ordering_fields = ['date', 'total_amount', 'created_at']
    ordering = ['-date']

    def get_serializer_class(self):
        if self.action in ['create', 'update', 'partial_update']:
            return CreateOrderSerializer
        return OrderSerializer

    @action(detail=True, methods=['post'])
    def mark_claim(self, request, pk=None):
        order = self.get_object()
        reason = request.data.get('reason', 'Bad Produce')

        try:
            credit_note = order.mark_as_claim(reason)
            return Response({
                'success': True,
                'message': f'Order marked as claim. Credit note {credit_note.code} created.',
                'credit_note_id': credit_note.id
            })
        except Exception as e:
            return Response({
                'success': False,
                'error': str(e)
            }, status=status.HTTP_400_BAD_REQUEST)

    @action(detail=True, methods=['post'])
    def cancel(self, request, pk=None):
        order = self.get_object()
        reason = request.data.get('reason', 'Order Cancelled')

        try:
            order.cancel_order(reason)
            return Response({
                'success': True,
                'message': f'Order {order.invoice_code} cancelled.'
            })
        except Exception as e:
            return Response({
                'success': False,
                'error': str(e)
            }, status=status.HTTP_400_BAD_REQUEST)

class OrderItemViewSet(viewsets.ModelViewSet):
    queryset = OrderItem.objects.all()
    serializer_class = OrderItemSerializer

class CustomerOrderDefaultsViewSet(viewsets.ModelViewSet):
    queryset = CustomerOrderDefaults.objects.all()
    serializer_class = CustomerOrderDefaultsSerializer
    filter_backends = [DjangoFilterBackend]
    filterset_fields = ['customer', 'product']
```

### Step 5: URL Configuration

#### 5.1 API URLs
```python
# backend/api/urls.py
from django.urls import path, include
from rest_framework.routers import DefaultRouter
from .views import (
    customers, products, orders, payments, expenses, analytics
)

router = DefaultRouter()
router.register(r'customers', customers.CustomerViewSet)
router.register(r'branches', customers.BranchViewSet)
router.register(r'products', products.ProductViewSet)
router.register(r'orders', orders.OrderViewSet)
router.register(r'order-items', orders.OrderItemViewSet)
router.register(r'order-defaults', orders.CustomerOrderDefaultsViewSet)
router.register(r'payments', payments.PaymentViewSet)
router.register(r'payment-types', payments.PaymentTypeViewSet)
router.register(r'expenses', expenses.ExpenseViewSet)
router.register(r'expense-categories', expenses.ExpenseCategoryViewSet)
router.register(r'credit-notes', payments.CreditNoteViewSet)

urlpatterns = [
    path('', include(router.urls)),
    path('analytics/', include('api.views.analytics')),
    path('auth/', include('rest_framework.urls')),
]
```

#### 5.2 Main URL Configuration
```python
# backend/zahara_backend/urls.py
from django.contrib import admin
from django.urls import path, include
from django.conf import settings
from django.conf.urls.static import static

urlpatterns = [
    path('', home, name='home'),
    path('graphs/', graphs, name='graphs'),
    path('admin/', admin.site.urls),

    # API URLs
    path('api/v1/', include('api.urls')),

    # Existing Django views (for backward compatibility)
    path('orders/', include('orders.urls')),
    path('payments/', include('payments.urls')),
    path('customers/', include('customers.urls')),
    path('products/', include('products.urls')),
    path('employees/', include('employees.urls')),
    path('expenses/', include('expenses.urls')),
    path('planting/', include('planting_schedule.urls')),
    path('invoices/', include('invoices.urls')),
]

if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
```

### Step 6: Installation Commands

```bash
# Install required packages
pip install djangorestframework
pip install django-cors-headers
pip install django-filter
pip install djangorestframework-simplejwt  # For JWT authentication

# Add to requirements.txt
echo "djangorestframework==3.15.1" >> requirements.txt
echo "django-cors-headers==4.3.1" >> requirements.txt
echo "django-filter==23.5" >> requirements.txt
echo "djangorestframework-simplejwt==5.3.0" >> requirements.txt

# Run migrations
python manage.py makemigrations
python manage.py migrate

# Create superuser for API testing
python manage.py createsuperuser

# Run development server
python manage.py runserver
```

### Step 7: Testing the API

#### 7.1 Test Endpoints
```bash
# Test customer list
curl -X GET "http://localhost:8000/api/v1/customers/" \
  -H "Authorization: Token YOUR_TOKEN_HERE"

# Test order creation
curl -X POST "http://localhost:8000/api/v1/orders/" \
  -H "Content-Type: application/json" \
  -H "Authorization: Token YOUR_TOKEN_HERE" \
  -d '{
    "customer": 1,
    "date": "2025-01-15",
    "items": [
      {
        "product": 1,
        "stem_length_cm": 60,
        "boxes": 10,
        "stems_per_box": 20,
        "price_per_stem": "2.50"
      }
    ]
  }'

# Test payment allocation
curl -X POST "http://localhost:8000/api/v1/payments/PAYMENT_UUID/allocate/" \
  -H "Content-Type: application/json" \
  -H "Authorization: Token YOUR_TOKEN_HERE" \
  -d '{
    "allocations": [
      {
        "order_id": 1,
        "amount": "500.00"
      }
    ]
  }'
```

This implementation provides a complete, production-ready REST API that your friend can use with Next.js and TypeScript. The API follows REST conventions, includes proper authentication, filtering, pagination, and comprehensive error handling.


