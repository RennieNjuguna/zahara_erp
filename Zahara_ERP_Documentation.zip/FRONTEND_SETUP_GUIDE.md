# Next.js + TypeScript Frontend Setup Guide

## Overview
This guide provides a complete setup for building a modern frontend for the Zahara ERP system using Next.js 14, TypeScript, and Tailwind CSS.

## Project Structure
```
zahara-frontend/
├── src/
│   ├── app/                    # Next.js 14 App Router
│   │   ├── (dashboard)/        # Route groups
│   │   │   ├── dashboard/
│   │   │   ├── customers/
│   │   │   ├── orders/
│   │   │   ├── payments/
│   │   │   └── layout.tsx
│   │   ├── api/                # API routes (if needed)
│   │   ├── auth/
│   │   ├── globals.css
│   │   ├── layout.tsx
│   │   └── page.tsx
│   ├── components/
│   │   ├── ui/                 # Reusable UI components
│   │   │   ├── button.tsx
│   │   │   ├── input.tsx
│   │   │   ├── table.tsx
│   │   │   └── modal.tsx
│   │   ├── forms/              # Form components
│   │   │   ├── customer-form.tsx
│   │   │   ├── order-form.tsx
│   │   │   └── payment-form.tsx
│   │   ├── charts/             # Chart components
│   │   │   ├── sales-chart.tsx
│   │   │   └── payment-chart.tsx
│   │   └── layout/             # Layout components
│   │       ├── sidebar.tsx
│   │       ├── header.tsx
│   │       └── footer.tsx
│   ├── lib/
│   │   ├── api.ts              # API client
│   │   ├── auth.ts             # Authentication
│   │   ├── utils.ts            # Utility functions
│   │   ├── validations.ts      # Form validations
│   │   └── constants.ts        # App constants
│   ├── hooks/
│   │   ├── use-customers.ts
│   │   ├── use-orders.ts
│   │   ├── use-payments.ts
│   │   └── use-auth.ts
│   ├── types/
│   │   ├── api.ts              # API types
│   │   ├── auth.ts             # Auth types
│   │   └── index.ts            # Main types
│   └── styles/
│       ├── globals.css
│       └── components.css
├── public/
│   ├── images/
│   └── icons/
├── package.json
├── tailwind.config.js
├── tsconfig.json
└── next.config.js
```

## Setup Instructions

### 1. Create Next.js Project
```bash
npx create-next-app@latest zahara-frontend --typescript --tailwind --eslint --app --src-dir --import-alias "@/*"
cd zahara-frontend
```

### 2. Install Additional Dependencies
```bash
# UI Components & Styling
npm install @headlessui/react @heroicons/react
npm install clsx tailwind-merge class-variance-authority
npm install lucide-react

# Forms & Validation
npm install react-hook-form @hookform/resolvers
npm install zod

# State Management
npm install zustand
npm install @tanstack/react-query

# Charts & Data Visualization
npm install recharts
npm install chart.js react-chartjs-2

# Date & Time
npm install date-fns

# HTTP Client
npm install axios

# Development Tools
npm install -D @types/node
npm install -D prettier prettier-plugin-tailwindcss
```

### 3. Package.json Configuration
```json
{
  "name": "zahara-frontend",
  "version": "0.1.0",
  "private": true,
  "scripts": {
    "dev": "next dev",
    "build": "next build",
    "start": "next start",
    "lint": "next lint",
    "type-check": "tsc --noEmit"
  },
  "dependencies": {
    "next": "14.0.4",
    "react": "^18",
    "react-dom": "^18",
    "@headlessui/react": "^1.7.17",
    "@heroicons/react": "^2.0.18",
    "@hookform/resolvers": "^3.3.2",
    "@tanstack/react-query": "^5.8.4",
    "axios": "^1.6.2",
    "chart.js": "^4.4.0",
    "class-variance-authority": "^0.7.0",
    "clsx": "^2.0.0",
    "date-fns": "^2.30.0",
    "lucide-react": "^0.294.0",
    "react-chartjs-2": "^5.2.0",
    "react-hook-form": "^7.48.2",
    "recharts": "^2.8.0",
    "tailwind-merge": "^2.0.0",
    "zod": "^3.22.4",
    "zustand": "^4.4.7"
  },
  "devDependencies": {
    "@types/node": "^20",
    "@types/react": "^18",
    "@types/react-dom": "^18",
    "autoprefixer": "^10.0.1",
    "eslint": "^8",
    "eslint-config-next": "14.0.4",
    "postcss": "^8",
    "prettier": "^3.1.0",
    "prettier-plugin-tailwindcss": "^0.5.7",
    "tailwindcss": "^3.3.0",
    "typescript": "^5"
  }
}
```

## Core Implementation

### 1. API Client Setup
```typescript
// src/lib/api.ts
import axios, { AxiosInstance, AxiosResponse } from 'axios';

// Types
export interface APIResponse<T> {
  data: T;
  message?: string;
  success: boolean;
}

export interface PaginatedResponse<T> {
  count: number;
  next: string | null;
  previous: string | null;
  results: T[];
}

export interface Customer {
  id: number;
  name: string;
  short_code: string;
  preferred_currency: 'KSH' | 'USD' | 'GBP' | 'EUR';
  branches: Branch[];
  order_statistics: {
    total_orders: number;
    total_sales: string;
    pending_orders: number;
    paid_orders: number;
    claimed_orders: number;
    cancelled_orders: number;
  };
  current_balance: string;
}

export interface Order {
  id: number;
  invoice_code: string;
  customer: Customer;
  total_amount: string;
  currency: string;
  date: string;
  status: 'pending' | 'paid' | 'claim' | 'cancelled';
  items: OrderItem[];
  payment_status: 'fully_paid' | 'partially_paid' | 'unpaid';
  outstanding_amount: string;
}

export interface Payment {
  payment_id: string;
  customer: Customer;
  amount: string;
  currency: string;
  payment_date: string;
  status: 'pending' | 'completed' | 'cancelled' | 'refunded';
  reference_number: string | null;
  allocated_amount: string;
  unallocated_amount: string;
}

// API Client Class
class ZaharaAPI {
  private client: AxiosInstance;
  private token: string | null = null;

  constructor() {
    this.client = axios.create({
      baseURL: process.env.NEXT_PUBLIC_API_URL || 'http://localhost:8000/api/v1',
      headers: {
        'Content-Type': 'application/json',
      },
    });

    // Request interceptor
    this.client.interceptors.request.use((config) => {
      if (this.token) {
        config.headers.Authorization = `Bearer ${this.token}`;
      }
      return config;
    });

    // Response interceptor
    this.client.interceptors.response.use(
      (response) => response,
      (error) => {
        if (error.response?.status === 401) {
          // Handle unauthorized access
          this.clearToken();
          window.location.href = '/auth/login';
        }
        return Promise.reject(error);
      }
    );
  }

  setToken(token: string) {
    this.token = token;
    localStorage.setItem('auth_token', token);
  }

  clearToken() {
    this.token = null;
    localStorage.removeItem('auth_token');
  }

  // Customers
  async getCustomers(params?: {
    search?: string;
    currency?: string;
    page?: number;
    page_size?: number;
  }): Promise<PaginatedResponse<Customer>> {
    const response = await this.client.get('/customers/', { params });
    return response.data;
  }

  async getCustomer(id: number): Promise<Customer> {
    const response = await this.client.get(`/customers/${id}/`);
    return response.data;
  }

  async createCustomer(data: {
    name: string;
    short_code: string;
    preferred_currency: 'KSH' | 'USD' | 'GBP' | 'EUR';
  }): Promise<Customer> {
    const response = await this.client.post('/customers/', data);
    return response.data;
  }

  async updateCustomer(id: number, data: Partial<Customer>): Promise<Customer> {
    const response = await this.client.patch(`/customers/${id}/`, data);
    return response.data;
  }

  async deleteCustomer(id: number): Promise<void> {
    await this.client.delete(`/customers/${id}/`);
  }

  // Orders
  async getOrders(params?: {
    customer?: number;
    status?: string;
    search?: string;
    date_from?: string;
    date_to?: string;
    page?: number;
    page_size?: number;
  }): Promise<PaginatedResponse<Order>> {
    const response = await this.client.get('/orders/', { params });
    return response.data;
  }

  async getOrder(id: number): Promise<Order> {
    const response = await this.client.get(`/orders/${id}/`);
    return response.data;
  }

  async createOrder(data: {
    customer: number;
    branch?: number;
    date: string;
    remarks?: string;
    items: Array<{
      product: number;
      stem_length_cm: number;
      boxes: number;
      stems_per_box: number;
      price_per_stem: string;
    }>;
  }): Promise<Order> {
    const response = await this.client.post('/orders/', data);
    return response.data;
  }

  async markOrderAsClaim(id: number, reason: string): Promise<{ success: boolean; message: string }> {
    const response = await this.client.post(`/orders/${id}/mark_claim/`, { reason });
    return response.data;
  }

  // Payments
  async getPayments(params?: {
    customer?: number;
    status?: string;
    payment_method?: string;
    date_from?: string;
    date_to?: string;
    search?: string;
    page?: number;
    page_size?: number;
  }): Promise<PaginatedResponse<Payment>> {
    const response = await this.client.get('/payments/', { params });
    return response.data;
  }

  async allocatePayment(paymentId: string, allocations: Array<{
    order_id: number;
    amount: string;
  }>): Promise<{
    success: boolean;
    allocations: Array<{ id: number; order_invoice: string; amount: string }>;
    remaining_amount: string;
  }> {
    const response = await this.client.post(`/payments/${paymentId}/allocate/`, { allocations });
    return response.data;
  }

  // Analytics
  async getDashboardStats(): Promise<{
    total_orders: number;
    total_sales: string;
    pending_orders: number;
    paid_orders: number;
    total_payments: string;
    total_outstanding: string;
    top_customers: Array<{ id: number; name: string; total_sales: string }>;
    monthly_sales: Array<{ month: string; sales: string; orders: number }>;
  }> {
    const response = await this.client.get('/analytics/dashboard/');
    return response.data;
  }
}

export const api = new ZaharaAPI();
```

### 2. React Query Hooks
```typescript
// src/hooks/use-customers.ts
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { api, type Customer } from '@/lib/api';

export function useCustomers(params?: {
  search?: string;
  currency?: string;
  page?: number;
  page_size?: number;
}) {
  return useQuery({
    queryKey: ['customers', params],
    queryFn: () => api.getCustomers(params),
  });
}

export function useCustomer(id: number) {
  return useQuery({
    queryKey: ['customers', id],
    queryFn: () => api.getCustomer(id),
    enabled: !!id,
  });
}

export function useCreateCustomer() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: api.createCustomer,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['customers'] });
    },
  });
}

export function useUpdateCustomer() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: ({ id, data }: { id: number; data: Partial<Customer> }) =>
      api.updateCustomer(id, data),
    onSuccess: (_, { id }) => {
      queryClient.invalidateQueries({ queryKey: ['customers'] });
      queryClient.invalidateQueries({ queryKey: ['customers', id] });
    },
  });
}

export function useDeleteCustomer() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: api.deleteCustomer,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['customers'] });
    },
  });
}
```

### 3. UI Components
```typescript
// src/components/ui/button.tsx
import * as React from "react"
import { cva, type VariantProps } from "class-variance-authority"
import { cn } from "@/lib/utils"

const buttonVariants = cva(
  "inline-flex items-center justify-center whitespace-nowrap rounded-md text-sm font-medium ring-offset-background transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50",
  {
    variants: {
      variant: {
        default: "bg-primary text-primary-foreground hover:bg-primary/90",
        destructive:
          "bg-destructive text-destructive-foreground hover:bg-destructive/90",
        outline:
          "border border-input bg-background hover:bg-accent hover:text-accent-foreground",
        secondary:
          "bg-secondary text-secondary-foreground hover:bg-secondary/80",
        ghost: "hover:bg-accent hover:text-accent-foreground",
        link: "text-primary underline-offset-4 hover:underline",
      },
      size: {
        default: "h-10 px-4 py-2",
        sm: "h-9 rounded-md px-3",
        lg: "h-11 rounded-md px-8",
        icon: "h-10 w-10",
      },
    },
    defaultVariants: {
      variant: "default",
      size: "default",
    },
  }
)

export interface ButtonProps
  extends React.ButtonHTMLAttributes<HTMLButtonElement>,
    VariantProps<typeof buttonVariants> {
  asChild?: boolean
}

const Button = React.forwardRef<HTMLButtonElement, ButtonProps>(
  ({ className, variant, size, asChild = false, ...props }, ref) => {
    const Comp = asChild ? "span" : "button"
    return (
      <Comp
        className={cn(buttonVariants({ variant, size, className }))}
        ref={ref}
        {...props}
      />
    )
  }
)
Button.displayName = "Button"

export { Button, buttonVariants }
```

### 4. Dashboard Component
```typescript
// src/app/(dashboard)/dashboard/page.tsx
'use client';

import { useQuery } from '@tanstack/react-query';
import { api } from '@/lib/api';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { SalesChart } from '@/components/charts/sales-chart';
import { RecentOrders } from '@/components/recent-orders';

export default function DashboardPage() {
  const { data: stats, isLoading } = useQuery({
    queryKey: ['dashboard-stats'],
    queryFn: api.getDashboardStats,
  });

  if (isLoading) {
    return <div>Loading...</div>;
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold tracking-tight">Dashboard</h1>
        <p className="text-muted-foreground">
          Welcome to Zahara Flowers ERP System
        </p>
      </div>

      {/* Stats Cards */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Orders</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats?.total_orders}</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Sales</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">KSH {stats?.total_sales}</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Pending Orders</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats?.pending_orders}</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Payments</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">KSH {stats?.total_payments}</div>
          </CardContent>
        </Card>
      </div>

      {/* Charts */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-7">
        <Card className="col-span-4">
          <CardHeader>
            <CardTitle>Sales Overview</CardTitle>
          </CardHeader>
          <CardContent className="pl-2">
            <SalesChart data={stats?.monthly_sales || []} />
          </CardContent>
        </Card>

        <Card className="col-span-3">
          <CardHeader>
            <CardTitle>Recent Orders</CardTitle>
          </CardHeader>
          <CardContent>
            <RecentOrders />
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
```

### 5. Customer Management
```typescript
// src/app/(dashboard)/customers/page.tsx
'use client';

import { useState } from 'react';
import { useCustomers, useDeleteCustomer } from '@/hooks/use-customers';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { CustomerTable } from '@/components/customer-table';
import { CustomerForm } from '@/components/forms/customer-form';
import { Plus, Search } from 'lucide-react';

export default function CustomersPage() {
  const [search, setSearch] = useState('');
  const [showForm, setShowForm] = useState(false);

  const { data: customers, isLoading } = useCustomers({ search });
  const deleteCustomer = useDeleteCustomer();

  const handleDelete = async (id: number) => {
    if (confirm('Are you sure you want to delete this customer?')) {
      await deleteCustomer.mutateAsync(id);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Customers</h1>
          <p className="text-muted-foreground">
            Manage your customer relationships
          </p>
        </div>
        <Button onClick={() => setShowForm(true)}>
          <Plus className="mr-2 h-4 w-4" />
          Add Customer
        </Button>
      </div>

      <div className="flex items-center space-x-2">
        <div className="relative flex-1 max-w-sm">
          <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Search customers..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="pl-8"
          />
        </div>
      </div>

      <CustomerTable
        customers={customers?.results || []}
        onDelete={handleDelete}
        loading={isLoading}
      />

      {showForm && (
        <CustomerForm
          onClose={() => setShowForm(false)}
          onSuccess={() => setShowForm(false)}
        />
      )}
    </div>
  );
}
```

### 6. Order Form Component
```typescript
// src/components/forms/order-form.tsx
'use client';

import { useState } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { useMutation, useQuery } from '@tanstack/react-query';
import { api } from '@/lib/api';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select } from '@/components/ui/select';

const orderSchema = z.object({
  customer: z.number().min(1, 'Customer is required'),
  branch: z.number().optional(),
  date: z.string().min(1, 'Date is required'),
  remarks: z.string().optional(),
  items: z.array(z.object({
    product: z.number().min(1, 'Product is required'),
    stem_length_cm: z.number().min(1, 'Stem length is required'),
    boxes: z.number().min(1, 'Boxes is required'),
    stems_per_box: z.number().min(1, 'Stems per box is required'),
    price_per_stem: z.string().min(1, 'Price is required'),
  })).min(1, 'At least one item is required'),
});

type OrderFormData = z.infer<typeof orderSchema>;

interface OrderFormProps {
  onSuccess: () => void;
  initialData?: Partial<OrderFormData>;
}

export function OrderForm({ onSuccess, initialData }: OrderFormProps) {
  const [items, setItems] = useState(initialData?.items || [{}]);

  const { data: customers } = useQuery({
    queryKey: ['customers'],
    queryFn: () => api.getCustomers({ page_size: 100 }),
  });

  const { data: products } = useQuery({
    queryKey: ['products'],
    queryFn: () => api.getProducts({ page_size: 100 }),
  });

  const createOrder = useMutation({
    mutationFn: api.createOrder,
    onSuccess: () => {
      onSuccess();
    },
  });

  const {
    register,
    handleSubmit,
    watch,
    setValue,
    formState: { errors },
  } = useForm<OrderFormData>({
    resolver: zodResolver(orderSchema),
    defaultValues: initialData,
  });

  const selectedCustomer = watch('customer');

  const addItem = () => {
    setItems([...items, {}]);
  };

  const removeItem = (index: number) => {
    setItems(items.filter((_, i) => i !== index));
  };

  const onSubmit = (data: OrderFormData) => {
    createOrder.mutate({
      ...data,
      items: items.filter(item => item.product && item.stem_length_cm),
    });
  };

  return (
    <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div>
          <label className="block text-sm font-medium mb-1">Customer</label>
          <select
            {...register('customer', { valueAsNumber: true })}
            className="w-full p-2 border rounded-md"
          >
            <option value="">Select customer</option>
            {customers?.results.map((customer) => (
              <option key={customer.id} value={customer.id}>
                {customer.name}
              </option>
            ))}
          </select>
          {errors.customer && (
            <p className="text-red-500 text-sm mt-1">{errors.customer.message}</p>
          )}
        </div>

        <div>
          <label className="block text-sm font-medium mb-1">Date</label>
          <Input
            type="date"
            {...register('date')}
            className={errors.date ? 'border-red-500' : ''}
          />
          {errors.date && (
            <p className="text-red-500 text-sm mt-1">{errors.date.message}</p>
          )}
        </div>
      </div>

      {/* Order Items */}
      <div>
        <div className="flex justify-between items-center mb-4">
          <h3 className="text-lg font-medium">Order Items</h3>
          <Button type="button" onClick={addItem} variant="outline">
            Add Item
          </Button>
        </div>

        {items.map((_, index) => (
          <div key={index} className="grid grid-cols-1 md:grid-cols-5 gap-4 p-4 border rounded-md mb-4">
            <div>
              <label className="block text-sm font-medium mb-1">Product</label>
              <select
                {...register(`items.${index}.product`, { valueAsNumber: true })}
                className="w-full p-2 border rounded-md"
              >
                <option value="">Select product</option>
                {products?.results.map((product) => (
                  <option key={product.id} value={product.id}>
                    {product.name}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium mb-1">Stem Length (cm)</label>
              <Input
                type="number"
                {...register(`items.${index}.stem_length_cm`, { valueAsNumber: true })}
              />
            </div>

            <div>
              <label className="block text-sm font-medium mb-1">Boxes</label>
              <Input
                type="number"
                {...register(`items.${index}.boxes`, { valueAsNumber: true })}
              />
            </div>

            <div>
              <label className="block text-sm font-medium mb-1">Stems/Box</label>
              <Input
                type="number"
                {...register(`items.${index}.stems_per_box`, { valueAsNumber: true })}
              />
            </div>

            <div className="flex items-end space-x-2">
              <div className="flex-1">
                <label className="block text-sm font-medium mb-1">Price/Stem</label>
                <Input
                  type="number"
                  step="0.01"
                  {...register(`items.${index}.price_per_stem`)}
                />
              </div>
              <Button
                type="button"
                variant="destructive"
                onClick={() => removeItem(index)}
                disabled={items.length === 1}
              >
                Remove
              </Button>
            </div>
          </div>
        ))}
      </div>

      <div className="flex justify-end space-x-4">
        <Button type="button" variant="outline" onClick={onSuccess}>
          Cancel
        </Button>
        <Button type="submit" disabled={createOrder.isPending}>
          {createOrder.isPending ? 'Creating...' : 'Create Order'}
        </Button>
      </div>
    </form>
  );
}
```

## Environment Configuration

### .env.local
```bash
NEXT_PUBLIC_API_URL=http://localhost:8000/api/v1
NEXT_PUBLIC_APP_NAME=Zahara Flowers ERP
```

### next.config.js
```javascript
/** @type {import('next').NextConfig} */
const nextConfig = {
  experimental: {
    appDir: true,
  },
  images: {
    domains: ['localhost'],
  },
  async rewrites() {
    return [
      {
        source: '/api/:path*',
        destination: `${process.env.NEXT_PUBLIC_API_URL}/:path*`,
      },
    ];
  },
};

module.exports = nextConfig;
```

### tailwind.config.js
```javascript
/** @type {import('tailwindcss').Config} */
module.exports = {
  darkMode: ["class"],
  content: [
    './pages/**/*.{ts,tsx}',
    './components/**/*.{ts,tsx}',
    './app/**/*.{ts,tsx}',
    './src/**/*.{ts,tsx}',
  ],
  theme: {
    container: {
      center: true,
      padding: "2rem",
      screens: {
        "2xl": "1400px",
      },
    },
    extend: {
      colors: {
        border: "hsl(var(--border))",
        input: "hsl(var(--input))",
        ring: "hsl(var(--ring))",
        background: "hsl(var(--background))",
        foreground: "hsl(var(--foreground))",
        primary: {
          DEFAULT: "hsl(var(--primary))",
          foreground: "hsl(var(--primary-foreground))",
        },
        secondary: {
          DEFAULT: "hsl(var(--secondary))",
          foreground: "hsl(var(--secondary-foreground))",
        },
        destructive: {
          DEFAULT: "hsl(var(--destructive))",
          foreground: "hsl(var(--destructive-foreground))",
        },
        muted: {
          DEFAULT: "hsl(var(--muted))",
          foreground: "hsl(var(--muted-foreground))",
        },
        accent: {
          DEFAULT: "hsl(var(--accent))",
          foreground: "hsl(var(--accent-foreground))",
        },
        popover: {
          DEFAULT: "hsl(var(--popover))",
          foreground: "hsl(var(--popover-foreground))",
        },
        card: {
          DEFAULT: "hsl(var(--card))",
          foreground: "hsl(var(--card-foreground))",
        },
      },
      borderRadius: {
        lg: "var(--radius)",
        md: "calc(var(--radius) - 2px)",
        sm: "calc(var(--radius) - 4px)",
      },
      keyframes: {
        "accordion-down": {
          from: { height: 0 },
          to: { height: "var(--radix-accordion-content-height)" },
        },
        "accordion-up": {
          from: { height: "var(--radix-accordion-content-height)" },
          to: { height: 0 },
        },
      },
      animation: {
        "accordion-down": "accordion-down 0.2s ease-out",
        "accordion-up": "accordion-up 0.2s ease-out",
      },
    },
  },
  plugins: [require("tailwindcss-animate")],
}
```

This setup provides a complete, production-ready Next.js frontend with TypeScript, modern UI components, and full integration with your Django REST API. Your friend can start building immediately with this foundation!


