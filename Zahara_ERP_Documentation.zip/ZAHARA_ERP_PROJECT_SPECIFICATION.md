# Zahara ERP System - Comprehensive Project Specification

## Project Overview

**Project Name**: Zahara Flowers Ltd ERP System
**Type**: Enterprise Resource Planning (ERP) System
**Industry**: Flower/Agricultural Business
**Technology Stack**: Django (Python), SQLite, Bootstrap, HTML/CSS/JavaScript
**Current Status**: Production-ready system with comprehensive features

## Business Domain

Zahara Flowers Ltd is a flower export business that manages:
- Customer orders for various flower products
- Multi-currency transactions (KSH, USD, GBP, EUR)
- Complex pricing based on stem length and customer-specific rates
- Payment tracking and allocation
- Credit note management for quality issues
- Expense tracking and management
- Planting schedule management
- Employee management

## System Architecture

### Backend Architecture
- **Framework**: Django 3.2.18
- **Database**: SQLite (development), PostgreSQL-ready (production)
- **API**: Django REST Framework
- **Authentication**: Django built-in authentication
- **File Storage**: Local media storage with PDF generation

### Frontend Architecture
- **UI Framework**: Bootstrap 5.3.3
- **Icons**: Bootstrap Icons 1.11.1
- **Interactive Elements**: HTMX 1.9.12, jQuery 3.7.1
- **Responsive Design**: Mobile-first approach
- **Theme**: Custom purple/magenta color scheme

### Project Structure
```
zahara_erp/
├── backend/                    # Django backend application
│   ├── customers/             # Customer management
│   ├── products/              # Product catalog
│   ├── orders/                # Order management
│   ├── invoices/              # Invoice and credit notes
│   ├── payments/              # Payment processing
│   ├── expenses/              # Expense tracking
│   ├── employees/             # Employee management
│   ├── planting_schedule/     # Farm planning
│   ├── templates/             # Base templates
│   ├── static/                # Static files
│   ├── media/                 # File uploads
│   └── zahara_backend/        # Django project settings
└── venv/                      # Python virtual environment
```

## Core Modules & Features

### 1. Customer Management (`customers/`)
**Purpose**: Manage customer relationships and pricing

**Key Models**:
- `Customer`: Customer information with currency preferences
- `Branch`: Customer branch management

**Features**:
- Multi-currency support (KSH, USD, GBP, EUR)
- Customer-specific pricing
- Branch management for large customers
- Order statistics and balance tracking

**Key Methods**:
- `get_order_statistics()`: Comprehensive order analytics
- `current_balance()`: Real-time balance calculation
- `outstanding_amount()`: Outstanding payment tracking
- `unallocated_payments()`: Unallocated payment tracking

### 2. Product Management (`products/`)
**Purpose**: Manage flower product catalog and pricing

**Key Models**:
- `Product`: Flower products with stem length specifications
- `CustomerProductPrice`: Customer-specific pricing matrix

**Features**:
- Stem length-based pricing
- Customer-specific pricing matrices
- Price history tracking
- Automatic price synchronization with orders

### 3. Order Management (`orders/`)
**Purpose**: Core order processing and management

**Key Models**:
- `Order`: Main order entity with status tracking
- `OrderItem`: Individual line items with pricing
- `CustomerOrderDefaults`: Remembers customer preferences

**Order Workflow**:
1. **Creation**: Order created with 'pending' status
2. **Processing**: Items added with automatic price lookup
3. **Payment**: Status changes to 'paid' when fully allocated
4. **Claims**: Status changes to 'claim' for quality issues
5. **Cancellation**: Status changes to 'cancelled'

**Key Features**:
- Automatic invoice code generation
- Logistics tracking (provider, cost, tracking number)
- Status-based workflow management
- Automatic price synchronization
- Customer preference memory

**Key Methods**:
- `is_paid()`: Payment status verification
- `outstanding_amount()`: Outstanding balance calculation
- `mark_as_claim()`: Quality issue handling
- `cancel_order()`: Order cancellation

### 4. Invoice & Credit Note Management (`invoices/`)
**Purpose**: Invoice generation and credit note processing

**Key Models**:
- `Invoice`: PDF invoice generation
- `CreditNote`: Comprehensive credit note system
- `CreditNoteItem`: Item-level credit tracking
- `AccountStatement`: Dynamic financial statements

**Credit Note Features**:
- Order-linked credit notes
- Partial credit support
- Automatic credit application logic
- Status-based credit handling:
  - Pending orders: Reduce order total
  - Paid orders: Create customer credit balance
- Comprehensive audit trail
- PDF generation capabilities

**Statement Types**:
- Reconciliation statements
- Periodic statements
- Full account history
- Custom date ranges

### 5. Payment Management (`payments/`)
**Purpose**: Comprehensive payment processing and tracking

**Key Models**:
- `Payment`: Main payment records
- `PaymentAllocation`: Links payments to specific orders
- `PaymentType`: Payment method configuration
- `CustomerBalance`: Real-time balance tracking
- `PaymentLog`: Comprehensive audit logging

**Payment Features**:
- Flexible payment allocation
- Multiple payment methods
- Currency support
- Real-time balance tracking
- Automatic order status updates
- Comprehensive audit trail

**Key Methods**:
- `allocate_to_orders()`: Flexible payment allocation
- `recalculate_balance()`: Balance recalculation
- `is_fully_allocated()`: Allocation status check

### 6. Expense Management (`expenses/`)
**Purpose**: Business expense tracking and management

**Key Models**:
- `Expense`: Main expense records
- `ExpenseCategory`: Categorization system
- `ExpenseAttachment`: File attachment support

**Features**:
- Multi-currency expense tracking
- Category-based organization
- Approval workflow
- File attachment support
- Recurring expense tracking
- Vendor management
- Due date tracking

### 7. Employee Management (`employees/`)
**Purpose**: Staff information management

**Key Models**:
- `Employee`: Staff records with contact information

**Features**:
- Contact information management
- Position tracking
- Employment date tracking

### 8. Planting Schedule (`planting_schedule/`)
**Purpose**: Farm planning and crop management

**Key Models**:
- `Crop`: Crop information with maturity tracking
- `FarmBlock`: Farm area management

**Features**:
- Crop maturity tracking
- Farm block management
- Status tracking (active, fallow, cleared, maintenance)

## Database Schema

### Key Relationships
```
Customer (1) ←→ (M) Order
Customer (1) ←→ (M) Branch
Customer (1) ←→ (M) CustomerProductPrice
Customer (1) ←→ (1) CustomerBalance

Order (1) ←→ (M) OrderItem
Order (1) ←→ (1) Invoice
Order (1) ←→ (M) CreditNote
Order (1) ←→ (M) PaymentAllocation

Product (1) ←→ (M) CustomerProductPrice
Product (1) ←→ (M) OrderItem

Payment (1) ←→ (M) PaymentAllocation

CreditNote (1) ←→ (M) CreditNoteItem
```

### Key Indexes
- Order status and date combinations
- Customer-payment relationships
- Product-customer pricing combinations
- Payment allocation tracking

## User Interface

### Design System
- **Color Scheme**: Purple/magenta theme with professional styling
- **Typography**: Segoe UI font family
- **Layout**: Sidebar navigation with responsive design
- **Components**: Bootstrap-based with custom styling

### Key Pages
1. **Dashboard**: Overview with metrics and quick actions
2. **Orders**: Order management with filtering and search
3. **Customers**: Customer management and statistics
4. **Products**: Product catalog and pricing
5. **Payments**: Payment processing and allocation
6. **Expenses**: Expense tracking and management
7. **Analytics**: Charts and reporting (graphs page)
8. **Credit Notes**: Credit note management

### Responsive Features
- Mobile-friendly sidebar navigation
- Responsive tables and forms
- Touch-friendly interface elements
- Adaptive layouts for different screen sizes

## Business Logic & Workflows

### Order Processing Workflow
1. **Order Creation**
   - Select customer and branch
   - Add products with stem lengths
   - Automatic price lookup from customer pricing
   - Generate unique invoice code
   - Set status to 'pending'

2. **Order Management**
   - Edit items and quantities
   - Update pricing (syncs to customer pricing)
   - Add logistics information
   - Track delivery status

3. **Payment Processing**
   - Record payments with allocation
   - Automatic status update to 'paid'
   - Real-time balance calculation

4. **Quality Issues**
   - Mark orders as 'claim'
   - Create credit notes automatically
   - Apply credits based on order status

### Payment Allocation Logic
- **Flexible Allocation**: Payments can be allocated across multiple orders
- **Automatic Status Updates**: Orders automatically become 'paid' when fully allocated
- **Balance Tracking**: Real-time customer balance updates
- **Audit Trail**: Complete payment history tracking

### Credit Note Processing
- **Order-Linked**: Every credit note must be linked to an order
- **Status-Based Logic**:
  - Pending orders: Reduce order total
  - Paid orders: Create customer credit balance
- **Partial Credits**: Support for item-level credit notes
- **Validation**: Prevents over-crediting

## API Endpoints

### Core URLs
- `/`: Dashboard
- `/graphs/`: Analytics
- `/orders/`: Order management
- `/customers/`: Customer management
- `/products/`: Product management
- `/payments/`: Payment processing
- `/expenses/`: Expense management
- `/employees/`: Employee management
- `/planting/`: Planting schedule
- `/invoices/`: Invoice and credit notes

### AJAX Endpoints
- Dynamic order item loading
- Customer order filtering
- Real-time balance updates
- Payment allocation interfaces

## File Management

### Media Storage
- **Invoice PDFs**: `media/invoices_pdfs/`
- **Account Statements**: `media/account_statements_pdfs/`
- **Expense Attachments**: `media/expense_attachments/YYYY/MM/DD/`

### Static Files
- **CSS**: Bootstrap and custom styling
- **JavaScript**: HTMX, jQuery, and custom scripts
- **Images**: System icons and assets

## Security & Authentication

### Authentication
- Django built-in authentication system
- Admin interface access control
- Session-based authentication

### Data Validation
- Model-level validation
- Form validation
- Business rule enforcement
- Currency consistency checks

### File Security
- Secure file upload handling
- File type validation
- Path traversal protection

## Performance Considerations

### Database Optimization
- Strategic indexing on frequently queried fields
- Efficient aggregate queries
- Pagination for large datasets

### Caching Strategy
- Balance calculation caching
- Customer statistics caching
- Template fragment caching

### Query Optimization
- Select_related and prefetch_related usage
- Efficient filtering and searching
- Minimal database hits

## Deployment Configuration

### Development Environment
- **Database**: SQLite
- **Debug Mode**: Enabled
- **Static Files**: Local serving
- **Media Files**: Local storage

### Production Readiness
- **Database**: PostgreSQL support
- **Static Files**: WhiteNoise or CDN ready
- **Media Files**: Cloud storage ready
- **Security**: Production settings template

### Dependencies
**Core Dependencies**:
- Django 3.2.18
- Django REST Framework 3.15.1
- ReportLab 3.6.12 (PDF generation)
- WeasyPrint 60.2 (PDF generation)

**Development Dependencies**:
- Multiple data analysis libraries
- Jupyter notebook support
- Machine learning libraries

## Recent Enhancements

### Credit Note System Overhaul
- Complete redesign of credit note functionality
- Order-linked credit notes with status-based logic
- Partial credit support with validation
- Comprehensive audit trails
- Professional PDF generation

### Payment System Enhancement
- Flexible payment allocation system
- Real-time balance tracking
- Automatic order status updates
- Comprehensive payment logging

### Order Status Management
- Clear workflow: pending → paid → claim/cancelled
- Automatic status updates based on payments
- Integration with credit note system
- Enhanced customer statistics

### Admin Interface Improvements
- Enhanced customer balance reporting
- Color-coded status indicators
- Bulk operations support
- Improved filtering and search

## Management Commands

### Data Management
- `populate_expense_categories`: Initialize expense categories
- `setup_initial_pricing`: Set up customer pricing
- `populate_stem_lengths`: Initialize stem length data
- `setup_payment_types`: Configure payment types

### System Maintenance
- `update_order_statuses`: Update order statuses
- `initialize_customer_balances`: Set up customer balances
- `sync_order_prices_to_customer_pricing`: Price synchronization

## Reporting & Analytics

### Financial Reports
- Customer balance reports
- Account statements (multiple types)
- Payment allocation reports
- Credit note summaries

### Business Analytics
- Order statistics by customer
- Sales trends and patterns
- Payment performance metrics
- Expense categorization

### Export Capabilities
- PDF generation for invoices and statements
- CSV export for data analysis
- Print-friendly formats

## Integration Points

### External Systems
- Payment gateway integration ready
- Email notification system ready
- Cloud storage integration ready
- API endpoints for external access

### Data Exchange
- CSV import/export capabilities
- PDF generation for external sharing
- JSON API for data exchange
- Webhook support ready

## Scalability Considerations

### Database Scaling
- PostgreSQL migration path
- Read replica support
- Connection pooling ready

### Application Scaling
- Stateless design
- Cache integration ready
- Load balancer compatible

### File Storage Scaling
- Cloud storage integration
- CDN support
- File compression and optimization

## Future Enhancements

### Planned Features
1. **Mobile Application**: Native mobile app for field operations
2. **Advanced Analytics**: Machine learning for demand forecasting
3. **Integration APIs**: REST API for third-party integrations
4. **Automated Workflows**: Email notifications and approvals
5. **Inventory Management**: Stock tracking and alerts
6. **Customer Portal**: Self-service customer interface

### Technical Improvements
1. **Microservices Architecture**: Service decomposition
2. **Real-time Updates**: WebSocket integration
3. **Advanced Security**: OAuth2 and JWT authentication
4. **Performance Optimization**: Redis caching and CDN
5. **Monitoring**: Application performance monitoring

## Conclusion

The Zahara ERP system is a comprehensive, production-ready solution for flower export businesses. It provides complete order-to-payment workflow management with sophisticated features for pricing, payment allocation, credit management, and financial reporting. The system is built with modern web technologies and follows Django best practices, making it maintainable, scalable, and extensible for future business needs.

The recent enhancements have significantly improved the system's capabilities, particularly in credit note management, payment processing, and financial reporting. The system is ready for production deployment and can handle the complex requirements of international flower export operations.


