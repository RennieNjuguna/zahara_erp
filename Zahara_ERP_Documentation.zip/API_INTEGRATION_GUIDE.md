# API Integration Guide for JavaScript Frontend

## Current API Endpoints (Ready to Use)

### Orders API
```javascript
// Get customer branches
GET /orders/get-branches/?customer_id={id}
Response: [{"id": 1, "name": "Nairobi Branch"}]

// Get customer orders
GET /orders/get-orders/?customer_id={id}
Response: [{"id": 1, "invoice_code": "FL001", "date": "2025-01-15", "total_amount": "1500.00"}]

// Get customer pricing
GET /orders/get-customer-pricing/?product_id={id}&stem_length={cm}
Response: {"success": true, "pricing": [...], "count": 5}

// Get defaults for customer-product
POST /orders/get-defaults/
Body: {"customer_id": 1, "product_id": 2}
Response: {"success": true, "stem_length_cm": 60, "price_per_stem": "2.50"}
```

### Payments API
```javascript
// Get outstanding orders
GET /payments/get-outstanding-orders/{customer_id}/
Response: {"orders": [{"id": 1, "invoice_code": "FL001", "outstanding_amount": "500.00"}]}

// Get customer balance
GET /payments/get-customer-balance/{customer_id}/
Response: {"balance": "1250.00", "currency": "KSH"}

// Allocate payment
POST /payments/allocate-payment/{payment_id}/
Body: {"allocations": [{"order_id": 1, "amount": "500.00"}]}
Response: {"success": true, "allocations": [...], "remaining_amount": "250.00"}

// Recalculate balance
POST /payments/recalculate-balance/{customer_id}/
Response: {"success": true, "balance": "1250.00", "currency": "KSH"}
```

## Recommended JavaScript Architecture

### 1. API Service Layer
```javascript
class ZaharaAPI {
    constructor() {
        this.baseURL = '';
        this.csrfToken = this.getCSRFToken();
    }

    async request(endpoint, options = {}) {
        const config = {
            headers: {
                'Content-Type': 'application/json',
                'X-CSRFToken': this.csrfToken,
                ...options.headers
            },
            ...options
        };

        const response = await fetch(endpoint, config);
        return response.json();
    }

    // Orders
    async getBranches(customerId) {
        return this.request(`/orders/get-branches/?customer_id=${customerId}`);
    }

    async getCustomerPricing(productId, stemLength) {
        return this.request(`/orders/get-customer-pricing/?product_id=${productId}&stem_length=${stemLength}`);
    }

    // Payments
    async getOutstandingOrders(customerId) {
        return this.request(`/payments/get-outstanding-orders/${customerId}/`);
    }

    async allocatePayment(paymentId, allocations) {
        return this.request(`/payments/allocate-payment/${paymentId}/`, {
            method: 'POST',
            body: JSON.stringify({allocations})
        });
    }
}
```

### 2. Component Architecture
```javascript
// Modern component-based approach
class OrderForm {
    constructor(container) {
        this.container = container;
        this.api = new ZaharaAPI();
        this.init();
    }

    init() {
        this.bindEvents();
        this.loadInitialData();
    }

    bindEvents() {
        this.container.querySelector('#customer-select').addEventListener('change', (e) => {
            this.loadBranches(e.target.value);
        });

        this.container.querySelector('#product-select').addEventListener('change', (e) => {
            this.loadPricing(e.target.value);
        });
    }

    async loadBranches(customerId) {
        const branches = await this.api.getBranches(customerId);
        this.updateBranchSelect(branches);
    }

    async loadPricing(productId) {
        const stemLength = this.container.querySelector('#stem-length').value;
        const pricing = await this.api.getCustomerPricing(productId, stemLength);
        this.updatePricingDisplay(pricing);
    }
}
```

### 3. State Management (Simple)
```javascript
class AppState {
    constructor() {
        this.state = {
            currentCustomer: null,
            selectedProducts: [],
            orderTotal: 0,
            payments: []
        };
        this.listeners = [];
    }

    setState(newState) {
        this.state = { ...this.state, ...newState };
        this.notifyListeners();
    }

    subscribe(listener) {
        this.listeners.push(listener);
    }

    notifyListeners() {
        this.listeners.forEach(listener => listener(this.state));
    }
}
```

## Integration with Existing Templates

### Option 1: Enhance Existing Pages
```html
<!-- Keep existing Django template structure -->
<div class="order-form-container">
    <form method="post" id="order-form">
        <!-- Existing Django form fields -->
        <select name="customer" id="customer-select">
            {% for customer in customers %}
                <option value="{{ customer.id }}">{{ customer.name }}</option>
            {% endfor %}
        </select>

        <!-- Add JavaScript enhancements -->
        <div id="dynamic-branches"></div>
        <div id="pricing-display"></div>
    </form>
</div>

<script>
// Enhance existing form with JavaScript
document.addEventListener('DOMContentLoaded', () => {
    new OrderForm(document.getElementById('order-form'));
});
</script>
```

### Option 2: Create New JavaScript-Heavy Pages
```html
<!-- New pages built primarily with JavaScript -->
<div id="payment-allocation-app">
    <div id="payment-details"></div>
    <div id="outstanding-orders"></div>
    <div id="allocation-interface"></div>
</div>

<script type="module">
import { PaymentAllocationApp } from './js/payment-allocation.js';
new PaymentAllocationApp(document.getElementById('payment-allocation-app'));
</script>
```

## Recommended Development Workflow

### Phase 1: Foundation (Week 1-2)
1. **Set up API service layer** - Create reusable API client
2. **Enhance existing forms** - Add real-time interactions to current pages
3. **Create component library** - Build reusable UI components

### Phase 2: Core Features (Week 3-4)
1. **Payment allocation interface** - Build interactive payment management
2. **Enhanced order form** - Real-time pricing and validation
3. **Dashboard improvements** - Add interactive charts and real-time data

### Phase 3: Advanced Features (Week 5-6)
1. **Real-time notifications** - WebSocket integration for live updates
2. **Advanced reporting** - Interactive charts and data visualization
3. **Mobile optimization** - Progressive Web App features

## Benefits of This Approach

### ✅ **Immediate Value**
- Enhance existing functionality without breaking changes
- Leverage existing API endpoints
- Maintain Django's security and form handling

### ✅ **Gradual Migration**
- Can migrate page by page
- No big-bang rewrite required
- Maintains backward compatibility

### ✅ **Modern User Experience**
- Real-time interactions
- Responsive design
- Professional UI components

### ✅ **Scalable Architecture**
- Component-based development
- Reusable API layer
- Easy to maintain and extend

## Next Steps

1. **Start with enhancing the order form** - Add real-time branch loading and pricing
2. **Create a payment allocation interface** - Build interactive payment management
3. **Add dashboard enhancements** - Real-time metrics and charts
4. **Implement progressive enhancement** - Ensure functionality works without JavaScript

This approach gives you the best of both worlds: leveraging your solid Django backend while creating a modern, interactive frontend experience.

